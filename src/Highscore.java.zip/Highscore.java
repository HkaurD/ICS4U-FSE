import java.io.*;
import java.util.Comparator;
import java.util.Scanner;
import java.util.HashMap;
import java.util.ArrayList;

public class Highscore {
    private final String filename;
    public ArrayList<Integer> points = new ArrayList<>();
    private HashMap<Integer, String> topScores = new HashMap<>();

    public Highscore(String name){
        filename = name;
    }

    // this method is used to read from the score.txt file; stores and returns the top five high scores
    public HashMap<Integer, String> loadScore(){
        points.sort(Comparator.reverseOrder()); // ordering the scores in descending order
        try{
            Scanner inFile = new Scanner(new BufferedReader(new FileReader(filename)));

            while(inFile.hasNext()){
                String name = inFile.next();
                int score = inFile.nextInt();
                points.add(score); // adding all the scores in an ArrayList to sort them in descending order
                topScores.put(score, name); // each score corresponds to a player's name
            }
            inFile.close();
        }
        catch(IOException ex){
            System.out.println(ex);
        }
        return topScores;
    }

    // this method is used to save a new score as the high score and it does return anything; takes in a string name and integer score
    public void saveScore(String name, int score){
        try{
            // used Mr. McKenzie's post on high scores using files
            PrintWriter outFile = new PrintWriter( new BufferedWriter (new FileWriter (filename, true)));
            outFile.println(name + " " + score); // prints the score to the score.txt file
            outFile.close(); // closing the file so that the score is added to the file
        }
        catch(IOException ex){
            System.out.println(ex);
        }
    }
}